# Dhamaka
A Python-Module that helps you crash Anyone's PC or Laptop. Note: *This is for don't educational Purposes only. Don't Use it against anyone*

## You can download Dhamaka in Windows by The following Steps:
- Download the *Dhamaka-0.1.1-py3-none-any.whl* file from the *dist* Directory
  
- Open the Powershell and Navigate to the directory where the *Dhamaka-0.1.1-py3-none-any.whl* is Installed

- #### ```Dhamaka-0.0.1-py3-none-any.whl```



## You can download Dhamaka in Linux by The following Steps:
- Download the *Dhamaka-0.1.1.tar.gz* file from the *dist* Directory

- Open the terminal and Navigate to the directory where the *Dhamaka-0.1.1.tar.gz* is Installed

- Extract the contents of the .tar.gz file By entering the following in the Terminal:
- #### ```tar -xzf Dhamaka-0.1.1.tar.gz```
- Navigate to the *Dhamaka-0.1.0* folder in Terminal by:
- #### ```cd Dhamaka-0.1.1```
- Now, install the module using pip by running the following command:
- #### ```pip install .```
- You can delete the directory and the file after the installation
