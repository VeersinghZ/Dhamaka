# Dhamaka
A Python-Module that helps you crash Anyone's PC or Laptop. Note: *This is for don't educational Purposes only. Don't Use it against anyone*

##You Can Download Dhamaka on your pc by This command:

- ####```pip install -i https://test.pypi.org/simple/ Dhamaka```
